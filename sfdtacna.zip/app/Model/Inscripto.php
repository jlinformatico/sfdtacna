<?php 
App::uses('AppModel', 'Model');

class Inscripto extends AppModel{
	public $displayField = 'nombre_completo';

}

?>